module.exports = {
  dialect: 'postgres',
  host: 'localhost',
  username: 'postgres',
  password: '1209200412Le@',
  database: 'trabalhofullstack-leandro',
  operatorAliases: false,
  define: {
    timestamps: false,
    underscored: false,
  }
}