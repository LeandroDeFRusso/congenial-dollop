# TRABALHOFULLSTACK-LEANDRO <br>
<br>

Neste repositório, se encontra toda a realização do trabalho pertinente ao cadastro de Pessoa, oriundos do docente Ravache.
